"""Run with:  python -m unittest discover tests -v"""
import glob, os, subprocess, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from opticore import optimizer as O, runner as R, ml

def opt(body, pre=''):
    return O.optimize(pre + 'int main(){' + body + '}')

class CompilerTests(unittest.TestCase):
    def types(self, r): return {l['type'] for l in r['log']}
    def test_fold_prop_dce(self):
        r = opt('int a = 2*3+4; return a;')
        self.assertIn('return 10;', r['optimized'])
        self.assertTrue({'constant_folding', 'constant_propagation', 'dead_code_elimination'} <= self.types(r))
    def test_algebra(self):
        r = O.optimize('int f(int x){ return x*1 + 0; }')
        self.assertIn('return x;', r['optimized'])
    def test_c_division_truncates_toward_zero(self):
        self.assertIn('return -3;', opt('return -7/2;')['optimized'])
    def test_no_fold_divide_by_zero(self):
        self.assertIn('1 / 0', opt('return 1/0;')['optimized'])
    def test_loop_variable_not_propagated(self):
        self.assertIn('return x;', opt('int x=1; for(int i=0;i<3;i++){x=x*2;} return x;')['optimized'])
    def test_address_taken_not_propagated(self):
        self.assertIn('return y;', opt('int y=1; int *p=&y; *p=5; return y;')['optimized'])
    def test_if_merge_is_safe(self):
        self.assertIn('return v;', opt('int c; int v=1; scanf("%d",&c); if(c){v=2;} return v;')['optimized'])
    def test_dead_code_after_return(self):
        self.assertNotIn('puts', opt('return 0; puts("x");')['optimized'])
    def test_if_zero_removed(self):
        self.assertNotIn('puts', opt('if (0) { puts("x"); } return 0;')['optimized'])
    def test_syntax_error_reports_line(self):
        with self.assertRaises(O.CSyntaxError) as c:
            O.optimize('int main() {\n int a = 5\n return a; }')
        self.assertIsNotNone(c.exception.line)
    def test_workload_nested_higher(self):
        a = O.optimize('int main(){for(int i=0;i<10;i++){} return 0;}')['workload']['score']
        b = O.optimize('int main(){for(int i=0;i<1000;i++){for(int j=0;j<1000;j++){}} return 0;}')['workload']['score']
        self.assertGreater(b, a)

@unittest.skipUnless(R.find_compiler(), 'no C compiler installed')
class BehaviourPreserved(unittest.TestCase):
    def test_all_valid_samples_same_output(self):
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for f in sorted(glob.glob(os.path.join(root, 'samples', '*.c'))):
            if 'syntax_error' in f: continue
            code = open(f).read()
            res = O.optimize(code)
            with tempfile.TemporaryDirectory() as tmp:
                _, _, e1 = R.compile_c(code, 'a', tmp); _, _, e2 = R.compile_c(res['optimized'], 'b', tmp)
                o1 = subprocess.run([e1], capture_output=True, text=True).stdout
                o2 = subprocess.run([e2], capture_output=True, text=True).stdout
            self.assertEqual(o1, o2, os.path.basename(f))

class MLTests(unittest.TestCase):
    def test_train_and_predict(self):
        m = ml.train(force_sample=True)
        self.assertGreater(m['accuracy'], 0.7)
        p = ml.predict(dict(cpu=5, ram=20, cpu_trend=0, ram_trend=0, process_count=100, workload=0))
        self.assertIn(p['label'], ml.LABELS)
        self.assertAlmostEqual(sum(p['probs'].values()), 1, places=2)

if __name__ == '__main__':
    unittest.main()

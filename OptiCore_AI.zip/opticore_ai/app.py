"""Flask backend: connects every module. Run with `python app.py`, open http://127.0.0.1:5000"""
import os
from flask import Flask, jsonify, render_template, request
from opticore import optimizer, runner, monitor, ml, decision, db

ROOT = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)

@app.get('/')
def index():
    return render_template('index.html')

@app.get('/api/metrics')
def metrics():
    return jsonify(latest=monitor.latest(), history=monitor.history(40), compiler=runner.find_compiler())

@app.get('/api/samples')
def samples():
    d = os.path.join(ROOT, 'samples')
    return jsonify([dict(name=f, code=open(os.path.join(d, f), encoding='utf-8').read()) for f in sorted(os.listdir(d)) if f.endswith('.c')])

@app.get('/api/model')
def model():
    return jsonify(ml.metrics())

@app.get('/api/history')
def history():
    return jsonify(db.recent())

@app.post('/api/analyze')
def analyze():
    d = request.get_json(force=True)
    code, run, force = d.get('code', ''), bool(d.get('run')), bool(d.get('force'))
    if not code.strip() or len(code) > 20000:
        return jsonify(ok=False, error='Code is empty or longer than 20,000 characters.')
    bad = runner.unsafe(code)
    if bad:
        return jsonify(ok=False, error=f'Blocked for safety: "{bad}" is not allowed in submitted programs.')
    try:
        res = optimizer.optimize(code)                                   # 1. compiler analysis
    except optimizer.CSyntaxError as e:
        return jsonify(ok=False, error=f'Syntax error: {e}', line=e.line)
    feats = monitor.features(res['workload']['score'])                   # 2. real system metrics
    risk = ml.predict(feats)                                             # 3. ML prediction
    allow = not (risk['label'] == 'high' and not force)
    validation, execution = runner.validate_and_run(code, res['optimized'], run, allow)   # 4. validate + run
    if validation.get('compile_error'):
        return jsonify(ok=False, error='Compiler error:\n' + validation['compile_error'])
    recs = decision.decide(res, risk, validation, execution, force)      # 5. decision engine
    a, b = execution.get('original', {}), execution.get('optimized', {})
    db.add(len(res['log']), risk['label'], res['workload']['score'], a.get('time_ms'), b.get('time_ms'),
           validation['ok'], code, res['optimized'])
    return jsonify(ok=True, **res, features=feats, risk=risk, validation=validation,
                   execution=execution, recommendations=recs, compiler=runner.find_compiler())

if __name__ == '__main__':
    db.init(); ml.ensure_model(); monitor.start()
    print('OptiCore AI running at http://127.0.0.1:5000')
    app.run(host='127.0.0.1', port=5000, debug=False)

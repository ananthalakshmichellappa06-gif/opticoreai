// OptiCore AI front end: talks to the Flask API, draws charts (Chart.js), animates with anime.js.
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;'}[c]));
const api = (u, o) => fetch(u, o).then(r => r.json());
const TYPE_NAME = {constant_folding: 'Constant folding', constant_propagation: 'Constant propagation',
  algebraic_simplification: 'Algebraic simplification', dead_code_elimination: 'Dead-code elimination'};
const charts = {};
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- animation helpers (anime.js) ---------- */
function stagger(sel, extra = {}) {
  if (reduce) return;
  anime({targets: sel, opacity: [0, 1], translateY: [14, 0], duration: 500, easing: 'easeOutCubic',
         delay: anime.stagger(70), ...extra});
}
function countUp(el, to, dec = 0) {
  if (reduce) { el.textContent = to.toFixed(dec); return; }
  const o = {v: 0};
  anime({targets: o, v: to, duration: 900, easing: 'easeOutExpo', update: () => el.textContent = o.v.toFixed(dec)});
}
function growBar(el, pct) { el.style.width = '0%'; requestAnimationFrame(() => el.style.width = pct + '%'); }

/* ---------- live monitor ---------- */
function makeLive() {
  charts.live = new Chart($('#liveChart'), {type: 'line',
    data: {labels: [], datasets: [
      {label: 'CPU %', data: [], borderColor: '#ffb524', tension: .3, pointRadius: 0},
      {label: 'RAM %', data: [], borderColor: '#6aa9ff', tension: .3, pointRadius: 0}]},
    options: {animation: false, maintainAspectRatio: false, scales: {y: {min: 0, max: 100, grid: {color: '#243a52'}}, x: {ticks: {maxTicksLimit: 6}, grid: {display: false}}},
              plugins: {legend: {labels: {color: '#8ba2b8'}}}}});
  Chart.defaults.color = '#8ba2b8';
}
async function pollMetrics() {
  try {
    const m = await api('/api/metrics'), l = m.latest;
    $('#cpuVal').textContent = l.cpu.toFixed(0); $('#cpuBar').style.width = l.cpu + '%';
    $('#ramVal').textContent = l.ram.toFixed(0); $('#ramBar').style.width = l.ram + '%';
    $('#ramHint').textContent = `${l.ram_used_gb} / ${l.ram_total_gb} GB`;
    const c = charts.live, h = m.history;
    c.data.labels = h.map(x => x.t); c.data.datasets[0].data = h.map(x => x.cpu); c.data.datasets[1].data = h.map(x => x.ram);
    c.update('none');
    const chip = $('#compilerChip');
    chip.textContent = m.compiler ? `C compiler: ${m.compiler}` : 'No gcc/clang found - static analysis only';
    chip.className = 'chip ' + (m.compiler ? 'chip--ok' : 'chip--bad');
  } catch (e) { /* server stopped */ }
}

/* ---------- analysis ---------- */
function showBanner(msg, kind) {
  const b = $('#banner'); b.textContent = msg; b.className = 'banner banner--' + kind;
  if (!reduce) anime({targets: b, opacity: [0, 1], translateX: [-12, 0], duration: 400, easing: 'easeOutCubic'});
}
async function analyze(run) {
  const code = $('#code').value;
  $('#banner').className = 'banner hidden';
  [$('#btnRun'), $('#btnStatic')].forEach(b => b.disabled = true);
  try {
    const r = await api('/api/analyze', {method: 'POST', headers: {'Content-Type': 'application/json'},
                                        body: JSON.stringify({code, run, force: $('#force').checked})});
    if (!r.ok) { $('#results').classList.add('hidden'); showBanner((r.line ? `Line ${r.line}: ` : '') + r.error, 'error'); return; }
    render(r);
    loadHistory();
  } catch (e) { showBanner('Could not reach the server: ' + e, 'error'); }
  finally { [$('#btnRun'), $('#btnStatic')].forEach(b => b.disabled = false); }
}

function item(cls, head, text, extra = '') {
  return `<div class="item item--${cls}"><div class="item__head">${head}</div><p class="item__text">${text}</p>${extra}</div>`;
}

function render(r) {
  $('#results').classList.remove('hidden');
  $('#origCode').textContent = r.original; $('#optCode').textContent = r.optimized;

  // optimization list
  const n = r.log.length; countUp($('#optCount'), n);
  $('#optHint').textContent = Object.entries(r.counts).map(([k, v]) => `${v} ${TYPE_NAME[k].toLowerCase()}`).join(', ') || 'nothing safe to change';
  $('#optList').innerHTML = n ? r.log.map(l => item(l.type,
      `<span class="badge">${TYPE_NAME[l.type]}</span><span class="item__title">${l.line ? 'line ' + l.line : ''}</span>`, esc(l.explanation),
      `<p class="item__diff">${esc(l.before)} &rarr; ${esc(l.after)}</p>`)).join('')
    : item('info', '<span class="item__title">No optimizations applied</span>', 'The compiler found nothing it could change safely.');

  // risk
  const k = r.risk.label;
  ['#riskBadge', '#riskBadge2'].forEach(s => { const e = $(s); e.textContent = k; e.className = 'risk risk--' + k + ' risk--pulse'; });
  $('#riskHint').textContent = `${(r.risk.confidence * 100).toFixed(0)}% confidence`;
  $('#riskConf').textContent = `Predicted ${k} resource pressure over the next ~10 s (${(r.risk.confidence * 100).toFixed(0)}% confidence)`;
  $('#probBars').innerHTML = ['low', 'moderate', 'high'].map(c => `<div class="prob"><span>${c}</span><div class="bar"><div class="bar__fill bar__fill--${c}" data-p="${(r.risk.probs[c] || 0) * 100}"></div></div><span>${((r.risk.probs[c] || 0) * 100).toFixed(0)}%</span></div>`).join('');
  document.querySelectorAll('#probBars .bar__fill').forEach(b => growBar(b, b.dataset.p));
  $('#riskReasons').innerHTML = r.risk.reasons.map(x => `<li>${esc(x)}</li>`).join('');
  const f = r.features;
  $('#featNote').textContent = `Model inputs: CPU ${f.cpu}%, RAM ${f.ram}%, CPU trend ${f.cpu_trend}, RAM trend ${f.ram_trend}, processes ${f.process_count}, code workload ${f.workload}/100`;

  // recommendations + validation
  $('#recList').innerHTML = r.recommendations.map(x => item(x.level, `<span class="item__title">${esc(x.action)}</span>`, esc(x.why))).join('');
  $('#valList').innerHTML = r.validation.checks.map(c => item(c.ok ? 'good' : 'fail',
      `<span class="item__title">${c.ok ? 'Passed' : 'Failed'}: ${esc(c.name)}</span>`, esc(c.detail || '')) ).join('') +
    (r.execution.executed ? '' : item('info', '<span class="item__title">Not executed</span>', esc(r.execution.reason || '')));

  perf(r.execution);
  stagger('.reveal');
  stagger('#optList .item'); stagger('#recList .item');
  $('#results').scrollIntoView({behavior: reduce ? 'auto' : 'smooth', block: 'start'});
}

function bar(id, title, a, b, unit) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart($('#' + id), {type: 'bar',
    data: {labels: ['Original', 'Optimized'], datasets: [{data: [a, b], backgroundColor: ['#6aa9ff', '#35d0b8'], borderRadius: 6}]},
    options: {maintainAspectRatio: false, plugins: {legend: {display: false}, title: {display: true, text: `${title} (${unit})`, color: '#e6eef6'}},
              scales: {y: {beginAtZero: true, grid: {color: '#243a52'}}, x: {grid: {display: false}}}}});
}
function perf(ex) {
  const box = $('#perfCharts'), tbl = $('#perfTable');
  if (!ex.executed) {
    box.classList.add('hidden'); tbl.innerHTML = '';
    $('#perfNote').textContent = (ex.reason || 'Not executed.') + ' No performance numbers are shown because none were measured.';
    return;
  }
  box.classList.remove('hidden');
  const a = ex.original, b = ex.optimized;
  $('#perfNote').textContent = `Real measurements: both programs compiled with -O0, wall time is the median of ${a.runs} runs. Tiny programs may show differences that are just measurement noise (spread: ${a.spread_ms} ms / ${b.spread_ms} ms).`;
  bar('chTime', 'Run time', a.time_ms, b.time_ms, 'ms'); bar('chMem', 'Peak memory', a.peak_mb, b.peak_mb, 'MB'); bar('chCpu', 'Program CPU time', a.cpu_ms, b.cpu_ms, 'ms');
  const ch = (x, y) => x ? ((y - x) / x * 100).toFixed(1) + '%' : '-';
  tbl.innerHTML = `<tr><th>Metric</th><th>Original</th><th>Optimized</th><th>Change</th></tr>` + [
    ['Run time (ms)', a.time_ms, b.time_ms], ['Peak memory (MB)', a.peak_mb, b.peak_mb],
    ['Program CPU time (ms)', a.cpu_ms, b.cpu_ms], ['System CPU during run (%)', a.sys_cpu, b.sys_cpu]]
    .map(([n, x, y]) => `<tr><td>${n}</td><td>${x}</td><td>${y}</td><td>${ch(x, y)}</td></tr>`).join('');
}

/* ---------- history + model panels ---------- */
async function loadHistory() {
  const h = await api('/api/history');
  $('#histTable').innerHTML = `<tr><th>Time</th><th>Opts</th><th>Risk</th><th>Workload</th><th>Time (ms)</th><th>Valid</th></tr>` +
    (h.map(x => `<tr><td>${x.ts}</td><td>${x.n_opts}</td><td><span class="risk risk--${x.risk}" style="font-size:13px;padding:0 10px">${x.risk}</span></td><td>${x.workload}</td><td>${x.t_orig ?? '-'} &rarr; ${x.t_opt ?? '-'}</td><td>${x.valid ? 'yes' : 'no'}</td></tr>`).join('')
     || '<tr><td colspan="6">No analyses yet.</td></tr>');
}
async function loadModel() {
  const m = await api('/api/model'), sim = m.source === 'sample';
  const rows = m.labels.map(l => `<tr><td>${l}</td><td>${m.report[l].precision.toFixed(2)}</td><td>${m.report[l].recall.toFixed(2)}</td><td>${m.report[l]['f1-score'].toFixed(2)}</td><td>${m.report[l].support}</td></tr>`).join('');
  const imp = Object.entries(m.importances).sort((a, b) => b[1] - a[1])
    .map(([k, v]) => `<div class="prob"><span>${k}</span><div class="bar"><div class="bar__fill bar__fill--cpu" data-p="${v * 100}"></div></div><span>${(v * 100).toFixed(0)}%</span></div>`).join('');
  $('#modelBox').innerHTML = `<p>Random Forest on <b>${m.rows}</b> rows <span class="${sim ? 'sim-tag' : 'real-tag'}">${sim ? 'SIMULATED data' : 'MEASURED data'}</span></p>
    <p class="note">Test accuracy <b>${(m.accuracy * 100).toFixed(1)}%</b> &middot; 5-fold CV <b>${(m.cv_accuracy * 100).toFixed(1)}%</b></p>
    <div class="table-wrap"><table class="table"><tr><th>Class</th><th>Precision</th><th>Recall</th><th>F1</th><th>Test rows</th></tr>${rows}</table></div>
    <p class="note" style="margin-top:12px">Feature importance</p>${imp}<p class="note">${esc(m.note)}</p>`;
  document.querySelectorAll('#modelBox .bar__fill').forEach(b => growBar(b, b.dataset.p));
}

/* ---------- start ---------- */
(async function init() {
  makeLive(); pollMetrics(); setInterval(pollMetrics, 1500);
  stagger('.js-intro .card', {delay: anime.stagger(90)});
  const samples = await api('/api/samples');
  samples.forEach((s, i) => $('#sampleSel').insertAdjacentHTML('beforeend', `<option value="${i}">${esc(s.name)}</option>`));
  $('#sampleSel').onchange = e => { if (e.target.value !== '') $('#code').value = samples[e.target.value].code; };
  $('#btnRun').onclick = () => analyze(true); $('#btnStatic').onclick = () => analyze(false);
  loadHistory(); loadModel();
})();

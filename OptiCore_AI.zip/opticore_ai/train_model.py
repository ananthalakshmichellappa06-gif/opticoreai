"""Train the Random Forest.  python train_model.py            -> auto (real data if present)
                            python train_model.py --sample   -> force simulated sample data
                            python train_model.py --collect 10 -> measure 10 minutes of real data first"""
import sys, json
from opticore import ml
if '--collect' in sys.argv:
    mins = int(sys.argv[sys.argv.index('--collect') + 1])
    print(f'Collecting real data for {mins} minutes (this will use your CPU/RAM)...')
    ml.collect_real_data(mins)
m = ml.train(force_sample='--sample' in sys.argv)
print(f"Data source: {m['source']} ({m['rows']} rows)  accuracy={m['accuracy']}  5-fold CV={m['cv_accuracy']}")
print(m['note']); print(json.dumps(m['confusion']))

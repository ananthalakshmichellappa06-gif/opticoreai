# OptiCore AI
**AI-Based Compiler Optimization and Predictive Overload Prevention System** - a college mini-project.

It takes C code, optimizes it with real compiler techniques, runs original and optimized versions under limits, measures real CPU / RAM / time, predicts resource-overload risk with a Random Forest, and recommends actions through a decision engine. Everything is shown on a web dashboard.

## 1. Folder structure
```
opticore_ai/
  app.py                 Flask backend (connects all modules, REST API)
  train_model.py         Train / retrain the ML model, optionally collect real data
  requirements.txt
  opticore/
    optimizer.py         MODULE 1  compiler: parse -> AST -> optimize -> C code
    monitor.py           MODULE 2  live CPU/RAM sampling (psutil) + ML features
    runner.py            MODULE 3  compile, validate, run with limits, measure
    ml.py                MODULE 4  Random Forest: data, training, metrics, prediction
    decision.py          MODULE 5  rule-based decision engine with explanations
    db.py                MODULE 6  SQLite optimization history
  templates/index.html   dashboard page
  static/css/style.css   styles (class-based, responsive)
  static/js/app.js       dashboard logic: Chart.js charts + anime.js animation
  samples/               6 sample C programs (incl. a syntax-error one)
  tests/test_opticore.py unit tests (13 tests)
  data/                  datasets, trained model, metrics, history database
```

## 2. Install and run on Windows (VS Code)
1. **Python 3.10+** from python.org. Tick **"Add Python to PATH"** while installing. Check: `python --version`
2. **A C compiler (needed to run/measure programs)** - open PowerShell and run:
   `winget install BrechtSanders.WinLibs.POSIX.UCRT`
   Close and reopen VS Code, then check: `gcc --version`. (Alternative: MSYS2 + `pacman -S mingw-w64-ucrt-x86_64-gcc`, then add its `bin` folder to PATH.)
   *Without a compiler the app still does syntax checking, optimization, prediction and the dashboard - it just cannot run/measure programs.*
3. Unzip the project, then in VS Code: **File > Open Folder** > `opticore_ai`. Open a terminal: **Terminal > New Terminal**.
4. Create and activate a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate
   ```
   (If PowerShell blocks it, run `Set-ExecutionPolicy -Scope Process Bypass` first.)
5. Install packages: `pip install -r requirements.txt`
6. (Optional) train the model now: `python train_model.py` - otherwise it trains automatically on first start.
7. Start: `python app.py` then open **http://127.0.0.1:5000** in your browser.
8. Run the tests: `python -m unittest discover tests -v`

The dashboard loads Chart.js, anime.js and Google Fonts from CDNs, so the browser needs internet access.

## 3. How to use the dashboard
Pick a sample (or paste C code) > **Optimize only** (static analysis) or **Optimize, run and measure** (also compiles and runs both versions). You get: original vs optimized code, an explanation of every change, the ML risk prediction with reasons, recommendations, validation results, measured before/after charts, and history.

## 4. How each module works (for your presentation)
**Module 1 - Compiler (`optimizer.py`).** The C code is parsed with *pycparser* into an AST. Passes run over the AST:
- *Constant folding*: `2*3+4` becomes `10` (uses C rules: integer division truncates toward zero; skips division by zero and 32-bit overflow).
- *Constant propagation*: tracks which `int` variables hold a known constant while walking the code in order. It forgets variables changed inside loops, merges knowledge after `if/else` (keeps only facts true on both paths), and never touches variables whose address is taken, `volatile`/`static` variables, or functions with `goto`/`switch`.
- *Algebraic simplification*: `x+0`, `x-0`, `x*1`, `x/1`, `x*0` (only when `x` has no side effects and is not a float).
- *Dead-code elimination*: code after `return/break/continue`, `if` with a constant condition, `while(0)`, unused variables and dead stores.
Each change is logged with line, before/after text and a plain-English reason. The AST is turned back into C code.

**Module 2 - Monitoring (`monitor.py`, `runner.py`).** A background thread samples real CPU% and RAM% every second (psutil). When a program runs, its peak memory and CPU time are polled and its wall time is the median of several runs.

**Module 3 - Safe running (`runner.py`).** Original and optimized code are compiled with `-O0` so only *our* optimizations differ. Programs run in a temporary folder with no input, a 5 s time limit, 256 MB memory limit (killed if exceeded), an output-size limit, and a blocklist of dangerous calls (`system`, `fopen`, `fork`, sockets, ...).

**Module 4 - ML (`ml.py`).** Random Forest (scikit-learn) predicts **low / moderate / high** pressure for the next ~10 seconds (label = max of CPU% and RAM% in the next 10 samples; <50 low, 50-80 moderate, >=80 high). Inputs: `cpu, ram, cpu_trend, ram_trend, process_count, workload` - where `workload` is a 0-100 score the compiler module estimates from loop nesting and bounds. Metrics: accuracy, 5-fold cross-validation, per-class precision/recall/F1, confusion matrix, feature importance.

**Module 5 - Decision engine (`decision.py`).** Combines compiler results + risk + validation + measurements into recommendations, each with a "why". High risk blocks execution unless you tick *force run*. If the optimized program does not compile or its output differs, it recommends keeping the original. It only claims a speed-up when the measured difference is larger than the run-to-run spread.

**Module 6 - Dashboard.** Flask serves the page and JSON API (`/api/analyze`, `/api/metrics`, `/api/history`, `/api/model`, `/api/samples`).

## 5. Honest notes about data and results (say this in your viva)
- **The bundled model is trained on SIMULATED data** (`data/sample_data.csv`, generated by `ml.generate_sample_data`). Its ~87% accuracy only shows the model can learn the simulation's rule. It is **not** real-world accuracy. The dashboard labels this clearly.
- For **real measured data**, run `python train_model.py --collect 10`. It runs random CPU/RAM stress bursts for 10 minutes, logs real psutil readings, labels each sample with the pressure that actually happened in the next 10 s, saves `data/real_data.csv`, and retrains. Do this on the computer you will demo on, with other programs closed - it loads your machine.
- Even then, accuracy is for *this PC and this kind of stress load*.
- Timing differences on tiny programs are often noise; the app says so instead of claiming a speed-up. Sample 01 (30M-iteration loop) can show a small real gain; sample 05 (prime counting) shows almost none, which is correct because its cost is algorithmic.
- Predictions use live system state plus the code's *estimated* workload (a static estimate, not a measurement).

## 6. Safety limits
The runner limits time, memory and output and blocks dangerous calls, but it is **not a full sandbox** (on Windows there is no kernel-level isolation here). Run only code you trust, or run the app inside a VM/Docker container for untrusted code.

## 7. Known limitations
- pycparser handles C99 without a preprocessor: `#include`/`#define` lines are kept, simple `#define NAME number` macros are substituted, function-like macros are not expanded. Comments are removed from the optimized output.
- Optimizations are per-function; globals, pointers, arrays and floating-point values are deliberately not propagated/folded, to preserve behaviour exactly.
- Real compilers already do these optimizations at `-O1` and above; this project reimplements them to show how they work.

## 8. Possible viva questions
- *Why an AST?* Passes need program structure, not text. - *Why `-O0`?* To measure only our own optimizations. - *Why not propagate loop variables?* They change every iteration; substituting would change behaviour. - *How is behaviour preserved?* Conservative rules + re-parse + compile + identical-output check. - *Why Random Forest?* Good on small tabular data, gives feature importance, little tuning.

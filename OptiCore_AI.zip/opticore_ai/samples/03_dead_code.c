#include <stdio.h>
/* Dead code: code after return, if(0) debug block, unused variables. */
int square_plus(int x) {
    int unused_tmp = 5 * 5;
    int y = x * x + 0;
    return y;
    printf("unreachable\n");
}
int main() {
    int debug = 0;
    int k = 3 + 4 * 2;
    if (debug) { printf("debug on\n"); }
    int r = square_plus(k) * 1;
    printf("%d\n", r);
    return 0;
}

#include <stdio.h>
/* Honest case: real algorithmic work, few compile-time optimizations available. */
int main() {
    int count = 0;
    for (int n = 2; n < 30000; n++) {
        int prime = 1;
        for (int d = 2; d * d <= n; d++) {
            if (n % d == 0) { prime = 0; break; }
        }
        if (prime) count++;
    }
    printf("primes below 30000: %d\n", count);
    return 0;
}

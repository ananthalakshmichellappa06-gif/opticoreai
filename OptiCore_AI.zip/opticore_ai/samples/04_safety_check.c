#include <stdio.h>
/* Safety test: x changes inside the loop and y's address is taken, so they must NOT be propagated. */
int main() {
    int x = 1;
    int n = 5;
    int y = 10;
    int *p = &y;
    for (int i = 0; i < n; i++) {
        x = x * 2;
        *p = *p + x;
    }
    printf("%d %d\n", x, y);
    return 0;
}

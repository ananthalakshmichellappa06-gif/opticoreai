#include <stdio.h>
/* Intentional syntax error (missing semicolon) to demonstrate error detection. */
int main() {
    int a = 5
    printf("%d\n", a);
    return 0;
}

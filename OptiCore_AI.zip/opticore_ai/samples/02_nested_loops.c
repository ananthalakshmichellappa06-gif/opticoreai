#include <stdio.h>
#define N 400
/* Nested loops: high workload score, constants come from variables and a macro. */
int main() {
    int rows = N;
    int cols = N / 2;
    long sum = 0;
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            sum += (i * 2 + j) % 5 + 2 * 3;
    printf("%ld\n", sum);
    return 0;
}

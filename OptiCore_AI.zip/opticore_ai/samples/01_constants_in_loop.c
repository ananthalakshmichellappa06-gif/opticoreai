#include <stdio.h>
/* Constants hidden behind variables: propagation + folding + algebra collapse the loop body. */
int main() {
    int a = 6;
    int b = 7;
    int c = a * b + 0;
    int unused = 99 * 2;
    long long total = 0;
    int i;
    for (i = 0; i < 30000000; i++) {
        total += (a * b + c * 1) % 7 + (10 * 10);
    }
    if (0) { printf("never printed\n"); }
    printf("total = %lld\n", total);
    return 0;
}

"""
MODULE 3 - SAFE COMPILE / RUN / MEASURE
Compiles original and optimized C with gcc/clang (-O0, so only OUR optimizations differ),
runs each under limits, and measures time, peak memory and CPU.
Limits: temp working dir, no stdin, time limit, memory limit (killed if exceeded),
output-size limit, blocked dangerous calls, and rlimits on Linux/macOS.
NOTE: this is a resource-limited runner, not a full security sandbox (see README).
"""
import os, re, shutil, statistics, subprocess, tempfile, time, psutil
from . import optimizer

BLOCKED = re.compile(
    r'\b(system|popen|fork|execl|execv|execvp|execlp|fopen|freopen|remove|rename|unlink|rmdir|socket|connect|'
    r'CreateProcess\w*|ShellExecute\w*|WinExec|signal|kill|asm|__asm__)\s*\(|\basm\b|'
    r'#\s*include\s*<(windows|winsock2?|unistd|sys/[^>]*)\.h>')

def unsafe(code):
    m = BLOCKED.search(code)
    return m.group(0).strip() if m else None

def find_compiler():
    for c in ('gcc', 'clang', 'cc'):
        if shutil.which(c):
            return c
    return None

def compile_c(code, name, tmp):
    src = os.path.join(tmp, name + '.c')
    exe = os.path.join(tmp, name + ('.exe' if os.name == 'nt' else ''))
    with open(src, 'w', encoding='utf-8') as f:
        f.write(code)
    r = subprocess.run([find_compiler(), '-O0', '-w', src, '-o', exe, '-lm'],
                       capture_output=True, text=True, timeout=30)
    return r.returncode == 0, r.stderr.strip(), exe

def _limits(mem_mb):
    if os.name != 'posix':
        return None
    import resource
    def f():
        resource.setrlimit(resource.RLIMIT_AS, (mem_mb * 2 * 2**20,) * 2)
        resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
        resource.setrlimit(resource.RLIMIT_FSIZE, (2**20,) * 2)
    return f

def _monitored(exe, cwd, timeout=5.0, mem_mb=256, max_out=100_000):
    """One run, polled with psutil: peak RAM, CPU time, system CPU, hard limits."""
    outp = os.path.join(cwd, 'out.txt')
    killed, peak, cpu, sysc = None, 0, 0.0, []
    psutil.cpu_percent(interval=None)
    with open(outp, 'wb') as fo:
        t0 = time.perf_counter()
        p = subprocess.Popen([exe], stdin=subprocess.DEVNULL, stdout=fo, stderr=subprocess.STDOUT,
                             cwd=cwd, preexec_fn=_limits(mem_mb))
        ps = psutil.Process(p.pid)
        while p.poll() is None:
            try:
                peak = max(peak, ps.memory_info().rss)
                t = ps.cpu_times(); cpu = t.user + t.system
            except psutil.Error:
                pass
            sysc.append(psutil.cpu_percent(interval=None))
            if time.perf_counter() - t0 > timeout: killed = 'time limit'
            elif peak > mem_mb * 2**20: killed = 'memory limit'
            elif os.path.getsize(outp) > max_out: killed = 'output limit'
            if killed:
                p.kill(); break
            time.sleep(0.003)
        p.wait()
        wall = time.perf_counter() - t0
    with open(outp, 'rb') as f:
        out = f.read(max_out).decode('utf-8', 'replace')
    return dict(stdout=out, returncode=p.returncode, killed=killed, first_wall=wall,
                peak_mb=round(peak / 2**20, 2), cpu_ms=round(cpu * 1000, 1),
                sys_cpu=round(statistics.mean(sysc), 1) if sysc else 0.0)

def measure(exe, cwd):
    """Monitored run (memory/CPU) + several clean timing runs (median wall time)."""
    m = _monitored(exe, cwd)
    if m['killed']:
        return m
    n = 5 if m['first_wall'] < 0.5 else 3 if m['first_wall'] < 1.5 else 1
    times = []
    for _ in range(n):
        t = time.perf_counter()
        subprocess.run([exe], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, cwd=cwd, timeout=10, preexec_fn=_limits(256))
        times.append((time.perf_counter() - t) * 1000)
    m.update(time_ms=round(statistics.median(times), 2), runs=n,
             spread_ms=round(max(times) - min(times), 2))
    return m

def chk(name, ok, detail=''):
    return dict(name=name, ok=ok, detail=detail)

def validate_and_run(orig, opt, run, allow):
    """Validate optimized code (re-parse, compile, same output) and optionally measure both."""
    checks, ex = [], dict(executed=False, reason=None)
    try:
        optimizer.parse(opt); checks.append(chk('Optimized code parses', True))
    except optimizer.CSyntaxError as e:
        checks.append(chk('Optimized code parses', False, str(e)))
    if not find_compiler():
        ex['reason'] = 'No C compiler (gcc/clang) found on PATH - only static validation was possible.'
        return dict(ok=all(c['ok'] for c in checks), checks=checks), ex
    with tempfile.TemporaryDirectory() as tmp:
        ok1, err1, exe1 = compile_c(orig, 'original', tmp)
        if not ok1:
            return dict(ok=False, checks=checks, compile_error=err1), ex
        ok2, err2, exe2 = compile_c(opt, 'optimized', tmp)
        checks.append(chk('Optimized code compiles', ok2, err2[:300]))
        if not (ok2 and all(c['ok'] for c in checks)):
            ex['reason'] = 'Optimized code failed validation, so it was not executed.'
        elif not run:
            ex['reason'] = 'Run & measure was not requested.'
        elif not allow:
            ex['reason'] = 'Execution deferred: predicted HIGH resource risk (tick "force run" to override).'
        else:
            a, b = measure(exe1, tmp), measure(exe2, tmp)
            match = (a['stdout'] == b['stdout'] and a['returncode'] == b['returncode']
                     and not a['killed'] and not b['killed'])
            why = a['killed'] or b['killed'] or ('' if match else 'program output differs')
            checks.append(chk('Same output and exit code as original', match, why))
            for r in (a, b):
                r['stdout'] = r['stdout'][:1500]
            ex.update(executed=True, original=a, optimized=b)
    return dict(ok=all(c['ok'] for c in checks), checks=checks), ex

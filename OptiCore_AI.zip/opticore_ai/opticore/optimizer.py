"""
MODULE 1 - COMPILER OPTIMIZER
Pipeline:  C source -> parse (pycparser) -> AST -> optimization passes -> regenerate C.
Passes: constant folding, constant propagation, algebraic simplification,
        dead-code elimination (unreachable code, constant conditions, unused variables).
Every change is written to a log with a plain-English explanation.
Safety rules: only plain `int` locals are propagated; anything whose address is taken,
that is volatile/static, declared twice, or lives in a function with goto/switch is left alone.
"""
import math, re
from collections import Counter
from pycparser import c_parser, c_ast as T, c_generator

# Lets pycparser accept common library type names without real headers.
PRELUDE = ("typedef unsigned long size_t; typedef struct _IO FILE; typedef long time_t; "
           "typedef long clock_t; typedef int bool;")
LO, HI = -2**31, 2**31 - 1            # 32-bit int range: never fold outside it
gen = c_generator.CGenerator()
INT_RE = re.compile(r'0|[1-9]\d*|0[xX][0-9a-fA-F]+')


class CSyntaxError(Exception):
    def __init__(self, msg, line=None):
        super().__init__(msg)
        self.line = line


# ---------- small helpers ----------
def walk(n):
    """Yield a node and all of its descendants."""
    if n is None:
        return
    yield n
    for _, c in n.children():
        yield from walk(c)

def map_children(node, fn):
    """Replace every child node with fn(child)."""
    for s in node.__slots__:
        if s in ('coord', '__weakref__'):
            continue
        v = getattr(node, s, None)
        if isinstance(v, T.Node):
            setattr(node, s, fn(v))
        elif isinstance(v, list):
            setattr(node, s, [fn(x) if isinstance(x, T.Node) else x for x in v])

def short(n, w=110):
    s = gen.visit(n) if isinstance(n, T.Node) else str(n)
    s = " ".join(s.split())
    return s if len(s) <= w else s[:w] + " ..."

def const_val(n):
    """Integer value of a plain int literal (or None)."""
    if isinstance(n, T.Constant) and n.type == 'int':
        neg = n.value.startswith('-')
        v = n.value[1:] if neg else n.value
        if INT_RE.fullmatch(v):
            x = int(v, 0)
            x = -x if neg else x
            if LO <= x <= HI:
                return x
    return None

def mk(v):
    return T.Constant('int', str(v))

def is_pure(e):
    """True if evaluating e has no side effects and cannot trap."""
    if isinstance(e, (T.Constant, T.ID)):
        return True
    if isinstance(e, T.BinaryOp):
        if e.op in ('/', '%') and not const_val(e.right):
            return False
        return is_pure(e.left) and is_pure(e.right)
    if isinstance(e, T.UnaryOp):
        return e.op in ('-', '+', '!', '~') and is_pure(e.expr)
    return False

def has_label(n):
    return any(isinstance(x, (T.Label, T.Case, T.Default)) for x in walk(n))

def assigned(node):
    """Names of simple variables written anywhere inside node."""
    s = set()
    for n in walk(node):
        if isinstance(n, T.Assignment) and isinstance(n.lvalue, T.ID):
            s.add(n.lvalue.name)
        elif isinstance(n, T.UnaryOp) and n.op in ('++', '--', 'p++', 'p--') and isinstance(n.expr, T.ID):
            s.add(n.expr.name)
    return s

def fold_bin(op, a, b):
    """C semantics for 32-bit ints. Returns None when unsafe (div by 0, overflow, shifts)."""
    if op == '+': r = a + b
    elif op == '-': r = a - b
    elif op == '*': r = a * b
    elif op in ('/', '%'):
        if b == 0: return None
        q = abs(a) // abs(b)
        q = q if (a < 0) == (b < 0) else -q        # C truncates toward zero
        r = q if op == '/' else a - b * q
    elif op == '<': r = int(a < b)
    elif op == '>': r = int(a > b)
    elif op == '<=': r = int(a <= b)
    elif op == '>=': r = int(a >= b)
    elif op == '==': r = int(a == b)
    elif op == '!=': r = int(a != b)
    elif op == '&&': r = int(bool(a) and bool(b))
    elif op == '||': r = int(bool(a) or bool(b))
    elif op == '&': r = a & b
    elif op == '|': r = a | b
    elif op == '^': r = a ^ b
    else: return None
    return r if LO <= r <= HI else None

def _quals(d):
    return (d.quals or []) + (getattr(d.type, 'quals', None) or [])

def eligible(d):
    """Can this declaration be tracked for constant propagation? (plain int, not volatile/static)"""
    t = d.type
    return (isinstance(t, T.TypeDecl) and isinstance(t.type, T.IdentifierType)
            and t.type.names == ['int'] and 'volatile' not in _quals(d)
            and not set(d.storage or []) & {'static', 'extern'})

def scalar_ok(d):
    """Can an unused variable of this declaration be deleted?"""
    t = d.type
    return (isinstance(t, T.TypeDecl) and isinstance(t.type, T.IdentifierType)
            and 'volatile' not in _quals(d) and not set(d.storage or []) & {'static', 'extern'})


# ---------- parsing ----------
def preprocess(code):
    """Pull out #lines (kept for the output); substitute simple '#define NAME number'."""
    header, body, defs = [], [], {}
    # pycparser cannot read comments: blank them out, keep strings and line numbers intact
    def blank(m):
        t = m.group(0)
        return t if t[0] in '"\'' else "\n" * t.count("\n")
    code = re.sub(r'"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\\n])*\'|/\*.*?\*/|//[^\n]*', blank, code, flags=re.S)
    for ln in code.splitlines():
        if ln.strip().startswith('#'):
            header.append(ln.strip())
            m = re.match(r'#\s*define\s+(\w+)\s+(-?\d+)\s*$', ln.strip())
            if m:
                defs[m.group(1)] = m.group(2)
            body.append('')                         # keep line numbers aligned
        else:
            body.append(ln)
    text = "\n".join(body)
    for k, v in defs.items():
        text = re.sub(r'\b%s\b' % re.escape(k), v, text)
    return header, text

def parse(code):
    header, text = preprocess(code)
    try:
        ast = c_parser.CParser().parse(PRELUDE + "\n" + text, filename='input.c')
    except c_parser.ParseError as e:
        m = re.search(r':(\d+):\d+:\s*(.*)', str(e))
        msg = m.group(2) if m else str(e)
        if msg.startswith('before:'):
            msg = f"unexpected '{msg[7:].strip()}' - check for a missing ';', ')' or '}}' on this or the previous line"
        raise CSyntaxError(msg, int(m.group(1)) - 1 if m else None)
    ast.ext = [e for e in ast.ext if e.coord.line != 1]      # drop the prelude
    return header, ast


# ---------- the optimizer ----------
class Optimizer:
    def __init__(self, ast):
        self.log = []
        self.elig = set()
        self.float_names = {d.name for d in walk(ast) if isinstance(d, T.Decl) and d.name
                            and any(x in ('float', 'double') for x in
                                    (getattr(getattr(d.type, 'type', None), 'names', None) or []))}

    def note(self, kind, node, before, after, why):
        line = node.coord.line - 1 if node is not None and getattr(node, 'coord', None) else None
        self.log.append(dict(type=kind, line=line, before=before, after=after, explanation=why))

    def rep(self, kind, old, new, why):
        self.note(kind, old, short(old), short(new), why)
        new.coord = old.coord
        return new

    def floaty(self, e):
        """Unknown/float typed? Then skip rewrites that are not exact for IEEE floats."""
        for n in walk(e):
            if (isinstance(n, T.ID) and n.name in self.float_names) or \
               isinstance(n, (T.FuncCall, T.ArrayRef, T.StructRef, T.Cast)) or \
               (isinstance(n, T.Constant) and n.type in ('float', 'double')) or \
               (isinstance(n, T.UnaryOp) and n.op == '*'):
                return True
        return False

    # --- pass: constant folding + algebraic simplification (expressions) ---
    def fold(self, e):
        if e is None:
            return None
        if isinstance(e, T.BinaryOp):
            e.left, e.right = self.fold(e.left), self.fold(e.right)
            a, b = const_val(e.left), const_val(e.right)
            if a is not None and b is not None:
                r = fold_bin(e.op, a, b)
                if r is not None:
                    return self.rep('constant_folding', e, mk(r),
                                    'Both operands are constants, so the compiler computes the result once instead of at every run.')
            return self.simplify(e)
        if isinstance(e, T.UnaryOp):
            if e.op in ('-', '+', '!', '~'):
                raw = isinstance(e.expr, T.Constant)
                e.expr = self.fold(e.expr)
                v = const_val(e.expr)
                if v is not None:
                    r = {'-': -v, '+': v, '!': int(v == 0), '~': ~v}[e.op]
                    if LO <= r <= HI:
                        if e.op == '-' and raw:         # plain negative literal: nothing to report
                            c = mk(r); c.coord = e.coord; return c
                        return self.rep('constant_folding', e, mk(r), 'The operand is constant, so the unary operation is evaluated at compile time.')
            return e
        map_children(e, self.fold)
        return e

    def simplify(self, e):
        L, R, op = e.left, e.right, e.op
        a, b = const_val(L), const_val(R)
        def done(new, why): return self.rep('algebraic_simplification', e, new, why)
        if op == '+':
            if b == 0 and not self.floaty(L): return done(L, 'Adding 0 never changes a value (x + 0 = x).')
            if a == 0 and not self.floaty(R): return done(R, 'Adding 0 never changes a value (0 + x = x).')
        if op == '-' and b == 0: return done(L, 'Subtracting 0 never changes a value (x - 0 = x).')
        if op == '*':
            if b == 1: return done(L, 'Multiplying by 1 never changes a value (x * 1 = x).')
            if a == 1: return done(R, 'Multiplying by 1 never changes a value (1 * x = x).')
            if b == 0 and is_pure(L) and not self.floaty(L): return done(mk(0), 'x * 0 is always 0 and x has no side effects.')
            if a == 0 and is_pure(R) and not self.floaty(R): return done(mk(0), '0 * x is always 0 and x has no side effects.')
        if op == '/' and b == 1: return done(L, 'Dividing by 1 never changes a value (x / 1 = x).')
        return e

    # --- pass: constant propagation (substitute known values) ---
    def prop(self, e, env):
        if e is None:
            return None
        if isinstance(e, T.ID):
            if e.name in env and e.name in self.elig:
                return self.rep('constant_propagation', e, mk(env[e.name]),
                                f"'{e.name}' is known to hold {env[e.name]} at this point, so its value is substituted.")
            return e
        if isinstance(e, T.Assignment):
            if not isinstance(e.lvalue, T.ID):
                e.lvalue = self.prop(e.lvalue, env)
            e.rvalue = self.prop(e.rvalue, env)
            return e
        if isinstance(e, T.UnaryOp) and e.op in ('++', '--', 'p++', 'p--', '&', 'sizeof'):
            return e
        if isinstance(e, T.StructRef):
            e.name = self.prop(e.name, env)             # never touch the member name
            return e
        if isinstance(e, T.NamedInitializer):
            e.expr = self.prop(e.expr, env)
            return e
        map_children(e, lambda c: self.prop(c, env))
        return e

    # --- statements: walk the code in execution order, tracking known constants in env ---
    def block(self, items, env):
        out = []
        for it in items:
            if out and isinstance(out[-1], (T.Return, T.Break, T.Continue, T.Goto)) and not has_label(it):
                self.note('dead_code_elimination', it, short(it), '(removed)',
                          'This statement comes after return/break/continue/goto, so it can never execute.')
                continue
            out.extend(self.stmt(it, env))
        return out

    def one(self, s, env):
        r = self.stmt(s, env)
        return r[0] if len(r) == 1 else T.Compound(r, s.coord)

    def expr_stmt(self, e, env):
        e = self.fold(self.prop(e, env))
        for n in assigned(e):
            env.pop(n, None)
        if isinstance(e, T.Assignment) and e.op == '=' and isinstance(e.lvalue, T.ID) and e.lvalue.name in self.elig:
            v = const_val(e.rvalue)
            if v is not None:
                env[e.lvalue.name] = v
        return e

    def stmt(self, s, env):
        if isinstance(s, T.Decl):
            if s.init is not None:
                s.init = self.fold(self.prop(s.init, env))
                for n in assigned(s.init):
                    env.pop(n, None)
            if s.name in self.elig:
                v = const_val(s.init)
                if v is not None: env[s.name] = v
                else: env.pop(s.name, None)
            return [s]
        if isinstance(s, T.Compound):
            s.block_items = self.block(s.block_items or [], env)
            return [s]
        if isinstance(s, T.Return):
            s.expr = self.fold(self.prop(s.expr, env))
            return [s]
        if isinstance(s, T.If):
            c = self.fold(self.prop(s.cond, env))
            for n in assigned(c): env.pop(n, None)
            v = const_val(c)
            if v is not None and not has_label(s.iftrue) and not has_label(s.iffalse):
                taken = s.iftrue if v else s.iffalse
                self.note('dead_code_elimination', s, f"if ({short(c)}) ...",
                          ('keeps only the ' + ('true' if v else 'false') + ' branch') if taken else '(removed)',
                          f"The condition is always {'true' if v else 'false'}, so the other branch can never run.")
                return [] if taken is None else [self.one(taken, env)]
            s.cond = c
            e1, e2 = dict(env), dict(env)
            s.iftrue = self.one(s.iftrue, e1)
            if s.iffalse is not None:
                s.iffalse = self.one(s.iffalse, e2)
            env.clear()
            env.update({k: v for k, v in e1.items() if e2.get(k) == v})   # keep only facts true on both paths
            return [s]
        if isinstance(s, T.While):
            for n in assigned(s): env.pop(n, None)        # loop may change these: forget them
            envl = dict(env)
            c = self.fold(self.prop(s.cond, envl))
            if const_val(c) == 0 and not has_label(s.stmt):
                self.note('dead_code_elimination', s, f"while ({short(c)}) ...", '(removed)',
                          'The loop condition is always false, so the body never executes.')
                return []
            s.cond = c
            s.stmt = self.one(s.stmt, envl)
            return [s]
        if isinstance(s, T.DoWhile):
            for n in assigned(s): env.pop(n, None)
            s.stmt = self.one(s.stmt, dict(env))
            s.cond = self.fold(s.cond)
            return [s]
        if isinstance(s, T.For):
            if isinstance(s.init, T.DeclList):
                for d in s.init.decls: self.stmt(d, env)
            elif s.init is not None:
                s.init = self.expr_stmt(s.init, env)
            for n in assigned(s.cond) | assigned(s.next) | assigned(s.stmt): env.pop(n, None)
            envl = dict(env)
            s.cond = self.fold(self.prop(s.cond, envl))
            s.next = self.fold(self.prop(s.next, dict(env)))
            s.stmt = self.one(s.stmt, envl)
            return [s]
        if isinstance(s, (T.Break, T.Continue, T.Goto, T.EmptyStatement, T.Label, T.Switch,
                          T.Case, T.Default, T.Pragma, T.Typedef, T.FuncDef)):
            return [s]
        return [self.expr_stmt(s, env)]                  # plain expression statement

    # --- pass: dead-code elimination of unused variables / dead stores ---
    def remove_unused(self, fd, cand):
        for _ in range(10):
            comps = [n for n in walk(fd.body) if isinstance(n, T.Compound)]
            stores = [(c, it) for c in comps for it in (c.block_items or [])
                      if isinstance(it, T.Assignment) and it.op == '=' and isinstance(it.lvalue, T.ID)]
            skip = {id(it.lvalue) for _, it in stores}
            reads = Counter(x.name for x in walk(fd.body) if isinstance(x, T.ID) and id(x) not in skip)
            changed = False
            for c, it in stores:
                nm = it.lvalue.name
                if nm in cand and reads[nm] == 0 and is_pure(it.rvalue):
                    c.block_items.remove(it); changed = True
                    self.note('dead_code_elimination', it, short(it), '(removed)',
                              f"'{nm}' is never read afterwards, so this assignment is a dead store.")
            total = Counter(x.name for x in walk(fd.body) if isinstance(x, T.ID))
            for c in comps:
                keep = []
                for it in c.block_items or []:
                    if isinstance(it, T.Decl) and it.name in cand and total[it.name] == 0 and (it.init is None or is_pure(it.init)):
                        changed = True
                        self.note('dead_code_elimination', it, short(it), '(removed)',
                                  f"Variable '{it.name}' is never used, so its declaration is deleted (saves a store and a stack slot).")
                    else:
                        keep.append(it)
                c.block_items = keep
            if not changed:
                break

    def optimize_function(self, fd):
        nodes = list(walk(fd))
        decls = [n for n in nodes if isinstance(n, T.Decl) and n.name]
        cnt = Counter(d.name for d in decls)
        addr = {u.expr.name for u in nodes if isinstance(u, T.UnaryOp) and u.op == '&' and isinstance(u.expr, T.ID)}
        jumps = any(isinstance(n, (T.Goto, T.Label, T.Switch)) for n in nodes)
        ok = lambda d: cnt[d.name] == 1 and d.name not in addr
        self.elig = set() if jumps else {d.name for d in decls if ok(d) and eligible(d)}
        body_ids = {id(n) for n in walk(fd.body) if isinstance(n, T.Decl)}
        cand = {d.name for d in decls if ok(d) and scalar_ok(d) and id(d) in body_ids}
        for _ in range(3):
            before = len(self.log)
            fd.body.block_items = self.block(fd.body.block_items or [], {})
            if len(self.log) == before:
                break
        self.remove_unused(fd, cand)


def workload(ast):
    """Static estimate of how heavy the program is (0-100), from loop nesting and bounds."""
    info = dict(total=0, loops=0, depth=0)
    def bound(n):
        c = getattr(n, 'cond', None)
        if isinstance(c, T.BinaryOp):
            v = const_val(c.right) if const_val(c.right) is not None else const_val(c.left)
            if v and v > 0: return v
        return 100                                        # unknown bound: assume 100
    def visit(n, depth, mult):
        if isinstance(n, (T.For, T.While, T.DoWhile)):
            depth += 1; mult *= bound(n)
            info['loops'] += 1; info['total'] += mult; info['depth'] = max(info['depth'], depth)
        for _, c in n.children():
            visit(c, depth, mult)
    visit(ast, 0, 1)
    return dict(score=min(100, int(14 * math.log10(1 + info['total']))), loops=info['loops'],
                max_depth=info['depth'], iterations=info['total'])

def optimize(code):
    """Main entry point: returns optimized code, the explanation log and workload estimate."""
    header, ast = parse(code)
    opt = Optimizer(ast)
    for ext in ast.ext:
        if isinstance(ext, T.FuncDef):
            opt.optimize_function(ext)
    out = "\n".join(header + ([''] if header else [])) + gen.visit(ast)
    return dict(original=code, optimized=out, log=opt.log,
                counts=dict(Counter(l['type'] for l in opt.log)), workload=workload(ast))

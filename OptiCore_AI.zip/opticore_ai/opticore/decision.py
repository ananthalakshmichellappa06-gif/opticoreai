"""
MODULE 5 - INTELLIGENT DECISION ENGINE
Rule-based layer that combines: compiler results + ML risk + validation + real measurements.
Every recommendation carries a 'why'. It never invents numbers: performance advice appears
only when real measurements exist.
"""
def rec(level, action, why):
    return dict(level=level, action=action, why=why)

def decide(res, risk, validation, execution, force):
    R, wl, n = [], res['workload'], len(res['log'])
    if not validation['ok']:
        R.append(rec('critical', 'Do not use the optimized code - keep the original',
                     'A validation check failed (see the validation panel), so program behaviour cannot be guaranteed.'))
    if risk['label'] == 'high':
        R.append(rec('warn', 'Defer or throttle this workload',
                     f"The model predicts HIGH pressure ({risk['confidence']:.0%} confidence). Close heavy apps or run later; "
                     "execution is blocked unless you tick 'force run'."))
    elif risk['label'] == 'moderate':
        R.append(rec('info', 'Run at lower priority / avoid parallel heavy tasks',
                     'Predicted MODERATE pressure: the program should run, but other heavy tasks may slow it down.'))
    else:
        R.append(rec('good', 'Safe to run now', 'Predicted LOW pressure: enough CPU and RAM headroom is available.'))
    if n == 0:
        R.append(rec('info', 'No safe compile-time optimizations found',
                     'Gains must come from the algorithm (fewer loops, better data structures), not from constant-level rewriting.'))
    else:
        R.append(rec('good', f'{n} compile-time optimization(s) applied',
                     'They remove work the program would otherwise repeat at run time (see the optimization list for each reason).'))
    if wl['max_depth'] >= 2:
        R.append(rec('warn', 'Reduce nested loops',
                     f"Loop nesting depth is {wl['max_depth']} with about {wl['iterations']:,} estimated iterations - the main CPU-pressure source. "
                     "Hoist invariant work out of inner loops or use a better algorithm."))
    elif wl['loops'] and wl['score'] >= 60:
        R.append(rec('info', 'Heavy loop detected', f"About {wl['iterations']:,} estimated iterations (workload score {wl['score']}/100)."))
    if execution.get('executed'):
        a, b = execution['original'], execution['optimized']
        if a.get('time_ms') and b.get('time_ms'):
            pct = (a['time_ms'] - b['time_ms']) / a['time_ms'] * 100
            noise = max(a.get('spread_ms', 0), b.get('spread_ms', 0))
            if pct > 5 and abs(a['time_ms'] - b['time_ms']) > noise:
                R.append(rec('good', 'Prefer the optimized version', f"Measured {pct:.1f}% faster ({a['time_ms']} ms -> {b['time_ms']} ms, median of {a['runs']} runs)."))
            else:
                R.append(rec('info', 'Speed difference is not significant',
                             f"Measured {a['time_ms']} ms vs {b['time_ms']} ms - within normal measurement noise, so no speed-up is claimed."))
    if risk['reasons'] and any('RAM' in r for r in risk['reasons'][:2]):
        R.append(rec('warn', 'Free memory first', 'RAM pressure is a contributor; close unused applications before running.'))
    return R

"""
MODULE 2 - RESOURCE MONITOR
A background thread samples real CPU% and RAM% with psutil once per second.
features() turns the recent history into the inputs of the ML model.
"""
import threading, time, collections, psutil

HIST = collections.deque(maxlen=120)
_started = False

def snapshot():
    vm = psutil.virtual_memory()
    s = dict(t=time.strftime('%H:%M:%S'), cpu=psutil.cpu_percent(interval=None), ram=vm.percent,
             ram_used_gb=round(vm.used / 2**30, 2), ram_total_gb=round(vm.total / 2**30, 2))
    HIST.append(s)
    return s

def start():
    global _started
    if _started:
        return
    _started = True
    psutil.cpu_percent(interval=None)                      # first call is always 0: prime it
    def loop():
        while True:
            snapshot(); time.sleep(1)
    threading.Thread(target=loop, daemon=True).start()

def latest():
    return HIST[-1] if HIST else snapshot()

def history(n=40):
    return list(HIST)[-n:]

def features(workload):
    """Feature vector for the ML model (same definitions as the training data)."""
    h = list(HIST) or [snapshot()]
    cur, prev = h[-1], h[-6:-1] or [h[-1]]
    avg = lambda k: sum(x[k] for x in prev) / len(prev)
    return dict(cpu=cur['cpu'], ram=cur['ram'], cpu_trend=round(cur['cpu'] - avg('cpu'), 2),
                ram_trend=round(cur['ram'] - avg('ram'), 2), process_count=len(psutil.pids()),
                workload=workload)

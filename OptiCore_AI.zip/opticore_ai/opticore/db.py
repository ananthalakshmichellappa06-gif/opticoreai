"""MODULE 6 - SQLite history of every analysis (only place a database is needed)."""
import os, sqlite3, time
PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'opticore.db')

def _c():
    c = sqlite3.connect(PATH); c.row_factory = sqlite3.Row; return c

def init():
    with _c() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT,
                     n_opts INTEGER, risk TEXT, workload INTEGER, t_orig REAL, t_opt REAL,
                     valid INTEGER, original TEXT, optimized TEXT)""")

def add(n_opts, risk, workload, t_orig, t_opt, valid, original, optimized):
    with _c() as c:
        c.execute("INSERT INTO history(ts,n_opts,risk,workload,t_orig,t_opt,valid,original,optimized) VALUES(?,?,?,?,?,?,?,?,?)",
                  (time.strftime('%Y-%m-%d %H:%M:%S'), n_opts, risk, workload, t_orig, t_opt, int(valid), original, optimized))

def recent(n=15):
    with _c() as c:
        return [dict(r) for r in c.execute("SELECT id,ts,n_opts,risk,workload,t_orig,t_opt,valid FROM history ORDER BY id DESC LIMIT ?", (n,))]
